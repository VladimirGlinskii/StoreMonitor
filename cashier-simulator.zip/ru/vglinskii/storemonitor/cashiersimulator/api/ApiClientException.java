package ru.vglinskii.storemonitor.cashiersimulator.api;

public class ApiClientException extends RuntimeException {
    public ApiClientException(Throwable cause) {
        super(cause);
    }
}
