package ru.vglinskii.storemonitor.cashiersimulator.api;

public class ApiInvalidArgumentsException extends RuntimeException {
    public ApiInvalidArgumentsException(Throwable cause) {
        super(cause);
    }
}
